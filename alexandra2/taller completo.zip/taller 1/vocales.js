
vocales=prompt("Ingrese la palabra para conocer las vocales: ")

console.log(vocales.length)