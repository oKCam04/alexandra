

let numero=111;

if (numero>0 && numero<101){
    console.log("Está dentro del rango")
}else if(numero>100){
    console.log("Su número está fuera de rango")
}