
numero=prompt("Ingresa un número para ver si es par o impar: ");

num=parseInt(numero);

num=num%2;

if (num===0){
    console.log("su número es par");
} else if (num>0){
    console.log("su número es impar");
}



