
numero=0;

if (numero==200){
    console.log("Su número es valido");
} else if (!numero || numero!=200){
    console.log("no es válido o está vacío")
}