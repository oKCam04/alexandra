
let numero=15;

if (numero%2==0 && numero>10){
    console.log("Si cumple la condiciones")
}else{
    console.log("No cumple las condiciones")
}