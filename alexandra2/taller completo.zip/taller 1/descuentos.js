
let valor=200000;

if (valor>100000){
    valor=valor*0.90;
} else if (valor>200000){
    valor=valor*0.80;
}

console.log("su valor final es: "+valor);