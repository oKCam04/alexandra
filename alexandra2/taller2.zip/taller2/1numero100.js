
function numeros(){
    for (let i=1; i<101;i++){
        console.log("Numero: "+i);
}
}

numeros();