//Reemplazar elementos en un arreglo: Crea una función que reemplace un elemento específico en un arreglo con otro valor.

let reemplazarElemento= "lilian";
let indice=2;
let reemplazo=["a", "b","c","d"];

function Reemplazar(){
    reemplazo[indice]=reemplazarElemento;
    console.log(reemplazo)
}Reemplazar();

