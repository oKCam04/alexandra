//17.	Filtrar por una propiedad en un arreglo de objetos: Crea una función que devuelva todos los 
//objetos en un arreglo que tengan una propiedad específica.

let personas=[
    {
        nombre:"lilian",
        genero: "femenino",
    },
    {
        nombre:"camilo",
        genero: "masculino",
        

    },
    {
        nombre:"constanza",
        genero: "femenino",
    },
]
let comparar="masculino"

function Filtrar(){

}
//FALTAAAAA