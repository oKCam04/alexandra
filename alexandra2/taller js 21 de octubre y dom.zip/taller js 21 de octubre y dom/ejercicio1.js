//Imprimir los números del 1 al 100: Crea una función que imprima los números del 1 al 100 usando un bucle for.
function numeros(){
    for(let i=1; i<101; i++){
        console.log("numero: "+i);

    }
}
numeros();


