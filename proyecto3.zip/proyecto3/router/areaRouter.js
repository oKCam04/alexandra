const express=require("express");
const area=express.Router();

area.get("/area",(req,res)=>{
    res.send("Estoy en el get de area");
});
area.post("/area",(req,res)=>{
    res.send("Estoy en el post de area");
});
area.put("/area",(req,res)=>{
    res.send("Estoy en el put de area");
});
area.delete("/area",(req,res)=>{
    res.send("Estoy en el delete de area");
});


module.exports=area;