const express=require("express");
const empresa=express.Router();

empresa.get("/empresa",(req,res)=>{
    res.send("Estoy en el get de empresa");
});
empresa.post("/empresa",(req,res)=>{
    res.send("Estoy en el post de empresa");
});
empresa.put("/empresa ",(req,res)=>{
    res.send("Estoy en el put de empresa");
});
empresa.delete("/empresa",(req,res)=>{
    res.send("Estoy en el delete de empresa");
});


module.exports=empresa;