const express=require("express");
const empleado=express.Router();

empleado.get("/empleado",(req,res)=>{
    res.send("Estoy en el get de empleado");
});
empleado.post("/empleado",(req,res)=>{
    res.send("Estoy en el post de empleado");
});
empleado.put("/empleado",(req,res)=>{
    res.send("Estoy en el put de empleado");
});
empleado.delete("/empleado",(req,res)=>{
    res.send("Estoy en el delete de empleado");
});


module.exports=empleado;