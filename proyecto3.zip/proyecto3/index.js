//archivo de ejecución
const express=require("express");
const app = express();



//mildeware
let empleados=require("./router/empleadoRouter")
let empresa=require("./router/empresaRouters") //
let area=require("./router/areaRouter") //

app.use("/ruta",empleados);
app.use("/ruta",empresa)
app.use("/ruta",area)










//configuración del servidor
const PORT=3000;
app.listen(PORT,()=>{
    console.log(`servidor corriendo en el puerto ${PORT}`)
});